

const Navbar = () => {
    return ( 
        <div className="navbar">
            <h3> TO DO LIST APP</h3>
        </div>
     );
}
 
export default Navbar;
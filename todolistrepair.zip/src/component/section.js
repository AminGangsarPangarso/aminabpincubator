const Section =()=>{
    return(
        <div className="section">
            <h2>Activity</h2>
            <img src="../gambar1/inigambar.png"></img>
        </div>
    )
}
export default Section